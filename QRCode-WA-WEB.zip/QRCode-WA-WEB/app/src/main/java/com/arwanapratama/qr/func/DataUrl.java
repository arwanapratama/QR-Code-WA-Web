package com.arwanapratama.qr.func;

public class DataUrl {
    public String screenName;
    public String screenURL;
}
