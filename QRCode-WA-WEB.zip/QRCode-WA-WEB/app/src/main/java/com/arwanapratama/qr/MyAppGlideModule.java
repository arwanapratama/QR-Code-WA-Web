package com.arwanapratama.qr;

import com.bumptech.glide.annotation.GlideModule;

/**
 * Created by kingdov on 17/01/2017.
 */

@GlideModule
public final class MyAppGlideModule extends com.bumptech.glide.module.AppGlideModule {
}
