package com.arwanapratama.qr.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.arwanapratama.qr.GlideApp;

import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.io.File;
import java.util.Collections;
import java.util.List;

import com.arwanapratama.qr.MainActivity;
import com.arwanapratama.qr.R;
import com.arwanapratama.qr.ScreenshotViewActivity;
import com.arwanapratama.qr.ScreenshotsActivity;
import com.arwanapratama.qr.func.DataUrl;

import static com.arwanapratama.qr.ScreenshotsActivity.activity;
import static com.arwanapratama.qr.ScreenshotsActivity.loadMedia;


public class ScreenAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private Context context;
    private LayoutInflater inflater;
    public List<DataUrl> data = Collections.emptyList();
    DataUrl current;

    public ScreenAdapter(Context context, List<DataUrl> data) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.data = data;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_view_screenshot, parent, false);
        MyHolder holder = new MyHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final MyHolder myHolder = (MyHolder) holder;
        current = data.get(position);
        myHolder.textView.setText(current.screenName);


        GlideApp.with(context).load(current.screenURL)
                .error(R.drawable.ic_placeholder_wallpaper)
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.ic_placeholder_wallpaper)
                .into(myHolder.imageView);

        myHolder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ScreenshotViewActivity.sData = data.get(position);
                Intent intent = new Intent(ScreenshotsActivity.activity, ScreenshotViewActivity.class);
                ScreenshotsActivity.activity.startActivity(intent);
                //admob.showInterstitial(true);
            }
        });

        myHolder.imageRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new android.support.v7.app.AlertDialog.Builder(activity)
                        .setMessage("Do you want to delete this screenshot?")
                        .setCancelable(false)
                        .setNegativeButton("No",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        })
                        .setPositiveButton("Yes",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        new File(data.get(position).screenURL).delete();
                                        loadMedia();
                                    }
                                }).show();

            }
        });

        myHolder.imageShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //ScreenshotsActivity.mShare(data.get(position).screenURL);
                ScreenshotsActivity.mShare("file://"+Environment.getExternalStorageDirectory()+"/DCIM/"+MainActivity.appName+File.separator+"/"+new File(data.get(position).screenURL).getName());


            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class MyHolder extends RecyclerView.ViewHolder {
        ImageView imageView, imageShare, imageRemove;
        TextView textView;
        boolean favorite = false;

        public MyHolder(View itemView) {
            super(itemView);
            imageRemove = itemView.findViewById(R.id.wallpaperRemove);
            imageView = itemView.findViewById(R.id.wallpaperThumb);
            imageShare = itemView.findViewById(R.id.wallpaperShare);
            textView = itemView.findViewById(R.id.wallpaperTitle);
        }
    }
}
