package com.arwanapratama.qr;


/**
 * Created by asus:KINGDOV on 009/05/2017.
 **/

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.arwanapratama.qr.func.ConfigAds;

import java.util.List;

public class SettingsActivity extends AppCompatActivity implements View.OnClickListener{

    public static LinearLayout rate,share,contact,privacy,moreapps,adunit,consentSdkSettings;
    static TextView app_name, version_name;
    ActionBar actionBar;
    Toolbar toolbar;
    public static Activity activity;
    ConsentSDK consentSDK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar= this.getActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator();
        this.setTitle("Settings");

        activity=this;

        ConfigAds.initialInterstitial(this);

        adunit = (LinearLayout)findViewById(R.id.bannerUnitAds);
        ConfigAds.admobBannerCall(this, adunit);

        consentSDK = new ConsentSDK.Builder(this)
                .addPrivacyPolicy(SettingsClass.privacy_policy_url) // Add your privacy policy url
                .addPublisherId(SettingsClass.publisherID) // Add your admob publisher id
                .build();

        app_name = (TextView) findViewById(R.id.app_name);
        version_name = (TextView) findViewById(R.id.version_name);
        app_name.setText(getResources().getString(R.string.app_name));
        try {
            version_name.setText("Version "+(this.getPackageManager().getPackageInfo(getPackageName(), 0)).versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        rate = (LinearLayout) findViewById(R.id.about_rate);
        share = (LinearLayout) findViewById(R.id.about_share);
        moreapps = (LinearLayout) findViewById(R.id.about_moreapps);
        contact = (LinearLayout) findViewById(R.id.about_contact);
        privacy = (LinearLayout) findViewById(R.id.about_privacy);
        consentSdkSettings = findViewById(R.id.consent);

        consentSdkSettings.setAlpha((float) 0.35);
        consentSDK.checkConsent(new ConsentSDK.ConsentCallback() {
            @Override
            public void onResult(boolean isRequestLocationInEeaOrUnknown) {
                // Your code
                if(isRequestLocationInEeaOrUnknown) {
                    consentSdkSettings.setAlpha((float) 1);
                    consentSdkSettings.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            consentSDK.checkConsent2(new ConsentSDK.ConsentCallback() {
                                @Override
                                public void onResult(boolean isRequestLocationInEeaOrUnknown) {
                                    // Your code
                                }
                            });
                        }
                    });
                }else {
                    consentSdkSettings.setAlpha((float) 0.35);
                }
            }
        });

        rate.setOnClickListener(this);
        share.setOnClickListener(this);
        moreapps.setOnClickListener(this);
        contact.setOnClickListener(this);
        privacy.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.about_rate:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+getPackageName())));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
                }
                break;
            case R.id.about_share:
//                if (mInterstitialAd.isLoaded()) mInterstitialAd.show();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = "Hey my friend(s) check out this amazing application \n https://play.google.com/store/apps/details?id="+ getPackageName() +" \n";
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
                break;
            case R.id.about_moreapps:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SettingsClass.more_apps_link)));
                } catch (android.content.ActivityNotFoundException anfe) {
                }
                break;
            case R.id.about_contact:
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{SettingsClass.contactMail});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Improvement : "+getPackageName());
                emailIntent.setType("text/plain");
                //emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Messg content");
                final PackageManager pm = getPackageManager();
                final List<ResolveInfo> matches = pm.queryIntentActivities(emailIntent, 0);
                ResolveInfo best = null;
                for(final ResolveInfo info : matches)
                    if (info.activityInfo.packageName.endsWith(".gm") || info.activityInfo.name.toLowerCase().contains("gmail"))
                        best = info;
                if (best != null)
                    emailIntent.setClassName(best.activityInfo.packageName, best.activityInfo.name);
                startActivity(emailIntent);
                break;
            case R.id.about_privacy:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SettingsClass.privacy_policy_url)));
                } catch (android.content.ActivityNotFoundException anfe) {
                }
                break;
        }

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        ConfigAds.showInterstitial(activity,true,false);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return true;
    }

}