package com.arwanapratama.qr.func;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.arwanapratama.qr.ConsentSDK;
import com.arwanapratama.qr.SettingsClass;

public class ConfigAds {
    public static int mCount = 0, mCount2=0;
    public static InterstitialAd mInterstitialAd;

    @SuppressLint("MissingPermission")
    public static void admobBannerCall(Activity acitivty , final LinearLayout linerlayout){
        linerlayout.setVisibility(View.VISIBLE);
        AdView adView = new AdView(acitivty);
        adView.setAdUnitId(SettingsClass.admBanner);
        adView.setAdSize(AdSize.SMART_BANNER);
        adView.loadAd(ConsentSDK.getAdRequest(acitivty));
        linerlayout.setVisibility(View.GONE);
        linerlayout.addView(adView);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                linerlayout.setVisibility(View.VISIBLE);
            }
        });
    }

    public static void initialInterstitial(final Activity activity){
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(SettingsClass.Interstitial);
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                requestNewInterstitial(activity);
            }
        });
        requestNewInterstitial(activity);
    }

    @SuppressLint("MissingPermission")
    public static void requestNewInterstitial(Context context) {
        mInterstitialAd.loadAd(ConsentSDK.getAdRequest(context));
    }


    public static void showInterstitial(Activity activity, boolean count, boolean touchCounter){
        if(count){
            if(touchCounter) {
                mCount++;
                if (SettingsClass.nbShowInterstitial == mCount) {
                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mCount = 0;
                    } else mCount--;
                }
            }else{
                mCount2++;
                if (SettingsClass.nbShowInterstitial2 == mCount2) {
                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mCount2 = 0;
                    } else mCount2--;
                }
            }
        } else if (mInterstitialAd.isLoaded()) mInterstitialAd.show();

    }
}
