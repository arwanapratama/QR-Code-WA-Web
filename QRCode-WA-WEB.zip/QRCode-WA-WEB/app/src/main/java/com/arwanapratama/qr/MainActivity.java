package com.arwanapratama.qr;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.arwanapratama.qr.func.ConfigAds;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements View.OnTouchListener, Handler.Callback {

        private static final String androidCurrent = "Linux; U; Android " + Build.VERSION.RELEASE;
        private static final String chrome = "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36";
        private static final String browser = chrome;
        private static final String device = androidCurrent;
       // private static final String userAgent = "Mozilla/5.0 (" + device + ") " + browser;
        private static final String userAgent = "Mozilla/5.0 (X11; U; Windows 10; en-US; rv:40.0) Gecko/20100101 Firefox/40.0";
        private static final String CAMERA_PERMISSION = "android.permission.CAMERA";
        private static final String AUDIO_PERMISSION = "android.permission.RECORD_AUDIO";
        private static final String WRITE_STORAGE =  Manifest.permission.WRITE_EXTERNAL_STORAGE;
        private static final String READ_STORAGE =  Manifest.permission.READ_EXTERNAL_STORAGE;
        private static final String[] STORAGE_PERMISSION = {WRITE_STORAGE,READ_STORAGE};
        private static final String[] VIDEO_PERMISSION = {CAMERA_PERMISSION, AUDIO_PERMISSION};
        private static final String WHATSAPP_WEB_URL = "https://web.whatsapp.com/\uD83C\uDF10/"+ Locale.getDefault().getLanguage();
        private static final int FILECHOOSER_RESULTCODE = 200;
        private static final int CAMERA_PERMISSION_RESULTCODE = 201;
        private static final int AUDIO_PERMISSION_RESULTCODE = 202;
        private static final int VIDEO_PERMISSION_RESULTCODE = 203;
        private static final int WRITE_PERMISSION_RESULTCODE = 204;
        private static final int READ_PERMISSION_RESULTCODE = 205;
        private static final int STORAGE_PERMISSION_RESULTCODE = 206;
        private static final String DEBUG_TAG = "WAWEBTOGO";

        private WebView webView;
        public static Activity activity ;
        ImageView settings;
        public static LinearLayout adunit;

        private ValueCallback<Uri[]> mUploadMessage;
        private PermissionRequest currentPermissionRequest;

        private static final int CLICK_ON_WEBVIEW = 1;
        private static final int CLICK_ON_URL = 2;
        private final Handler handler = new Handler(this);

        final StringBuilder s = new StringBuilder();
        ConsentSDK consentSDK;
        public static String appName;


    @SuppressLint("NewApi")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            activity = this;
            appName = getResources().getString(R.string.app_name);

            consentSDK = new ConsentSDK.Builder(this)
                    .addPrivacyPolicy(SettingsClass.privacy_policy_url) // Add your privacy policy url
                    .addPublisherId(SettingsClass.publisherID) // Add your admob publisher id
                    .build();

            consentSDK.checkConsent(new ConsentSDK.ConsentCallback() {
                @Override
                public void onResult(boolean isRequestLocationInEeaOrUnknown) {
                    // Your code
                }
            });

            adunit = (LinearLayout) findViewById(R.id.unitBanner);
            ConfigAds.admobBannerCall(this,adunit);

            ConfigAds.initialInterstitial(this);

            settings = (ImageView) findViewById(R.id.settings);

            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

            s.append("<html></html>");
            webView = findViewById(R.id.webview);
            webView.getSettings().setJavaScriptEnabled(true); //for wa web
            webView.setOnTouchListener(this);
            webView.getSettings().setAllowContentAccess(true); // for camera
            webView.getSettings().setAllowFileAccess(true);
            webView.getSettings().setAllowFileAccessFromFileURLs(true);
            webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
            webView.getSettings().setMediaPlaybackRequiresUserGesture(true); //for audio messages - false in the past
            webView.getSettings().setDomStorageEnabled(true); //for html5 app
            webView.getSettings().setAppCacheEnabled(true); // app cache
            webView.getSettings().setAppCachePath(getCacheDir().getAbsolutePath()); //app cache
            webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE); //app cache
            webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
            webView.setScrollbarFadingEnabled(true);
            webView.getSettings().setUseWideViewPort(false);
            webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
            webView.getSettings().setPluginState(WebSettings.PluginState.ON);
            webView.getSettings().setLoadWithOverviewMode(true);
            webView.getSettings().setLoadsImagesAutomatically(true);
            webView.getSettings().setSaveFormData(true);
            webView.getSettings().setBlockNetworkImage(false);
            webView.getSettings().setBlockNetworkLoads(false);
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
            webView.getSettings().setSupportMultipleWindows(true);
            webView.getSettings().setNeedInitialFocus(false);
            webView.getSettings().setDatabaseEnabled(true);
            webView.getSettings().setGeolocationEnabled(true);

            webView.setWebChromeClient(new WebChromeClient() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                if (request.getResources()[0].equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                    if (ContextCompat.checkSelfPermission(activity, CAMERA_PERMISSION) == PackageManager.PERMISSION_DENIED
                            && ContextCompat.checkSelfPermission(activity, AUDIO_PERMISSION) == PackageManager.PERMISSION_DENIED) {
                        ActivityCompat.requestPermissions(activity, VIDEO_PERMISSION, VIDEO_PERMISSION_RESULTCODE);
                        currentPermissionRequest = request;
                    } else if (ContextCompat.checkSelfPermission(activity, CAMERA_PERMISSION) == PackageManager.PERMISSION_DENIED) {
                        ActivityCompat.requestPermissions(activity, new String[]{CAMERA_PERMISSION}, CAMERA_PERMISSION_RESULTCODE);
                        currentPermissionRequest = request;
                    } else if (ContextCompat.checkSelfPermission(activity, AUDIO_PERMISSION) == PackageManager.PERMISSION_DENIED) {
                        ActivityCompat.requestPermissions(activity, new String[]{AUDIO_PERMISSION}, AUDIO_PERMISSION_RESULTCODE);
                        currentPermissionRequest = request;
                    } else {
                        request.grant(request.getResources());
                    }
                } else if (request.getResources()[0].equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                    if (ContextCompat.checkSelfPermission(activity, AUDIO_PERMISSION) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        ActivityCompat.requestPermissions(activity, new String[]{AUDIO_PERMISSION}, AUDIO_PERMISSION_RESULTCODE);
                        currentPermissionRequest = request;
                    }
                } else {
                    try {
                        request.grant(request.getResources());
                    } catch (RuntimeException e) {
                        Log.d(DEBUG_TAG, "Granting permissions failed", e);
                    }
                }
            }

            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d(DEBUG_TAG, "WebView console message: " + cm.message());
                return super.onConsoleMessage(cm);
            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                mUploadMessage = filePathCallback;
                Intent chooserIntent = fileChooserParams.createIntent();
                MainActivity.this.startActivityForResult(chooserIntent, FILECHOOSER_RESULTCODE);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                view.scrollTo(0, 0);
        }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    Log.d(DEBUG_TAG, request.getUrl().toString());
                    if (request.getUrl().toString().contains("web.whatsapp.com")) {
                        return false;
                    } else if (request.getUrl().toString().contains("www.whatsapp.com")) {
                        loadWhatsapp();
                    } else {
                        Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                        startActivity(intent);
                    }
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) {
                    Log.d(DEBUG_TAG, url);
                    if (url.contains("web.whatsapp.com")) {
                        return false;
                    } else if (url.contains("www.whatsapp.com")) {
                        loadWhatsapp();
                    } else {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                    }
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, url);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                String msg = String.format("Error: %s - %s", error.getErrorCode(), error.getDescription());
                Log.d(DEBUG_TAG, msg);
            }

            public void onUnhandledKeyEvent(WebView view, KeyEvent event) {
                Log.d(DEBUG_TAG, "Unhandled key event: " + event.toString());
            }
        });

            // webView.addJavascriptInterface(new NotificationInterface(this), "Android");
            // webView.addJavascriptInterface(new FunctionCallInterceptor(), "Interceptor");

            webView.getSettings().setUserAgentString(userAgent);
            if (savedInstanceState == null) {
                webView.loadUrl(WHATSAPP_WEB_URL);
            } else {
                Log.d(DEBUG_TAG, "savedInstanceState is present");
            }

            settings.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ConfigAds.showInterstitial(activity,true,false);
                    LayoutInflater inflater = getLayoutInflater();
                    View alertLayout = inflater.inflate(R.layout.dailog_settings, null);
                    TextView main = alertLayout.findViewById(R.id.home);
                    TextView reload = alertLayout.findViewById(R.id.reload);
                    TextView logout = alertLayout.findViewById(R.id.logout);
                    TextView rate = alertLayout.findViewById(R.id.rate);
                    TextView share = alertLayout.findViewById(R.id.share);
                    TextView help = alertLayout.findViewById(R.id.guideapp);
                    TextView screenshot = alertLayout.findViewById(R.id.screenshot);
                    TextView screenshots = alertLayout.findViewById(R.id.screenshots);

                    TextView otherSettings = alertLayout.findViewById(R.id.other_settings);

                    final android.support.v7.app.AlertDialog.Builder alert = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
                    alert.setTitle("Main Settings");
                    // this is set the view from XML inside AlertDialog
                    alert.setView(alertLayout);
                    // disallow cancel of AlertDialog on click of back button and outside touch
                    alert.setCancelable(false);



                    alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });


                    final android.support.v7.app.AlertDialog dialog = alert.create();
                    dialog.show();

                    main.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            webView.loadUrl("https://web.whatsapp.com");
                            dialog.dismiss();
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });

                    screenshot.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (ContextCompat.checkSelfPermission(activity, WRITE_STORAGE) == PackageManager.PERMISSION_DENIED  &&
                                    ContextCompat.checkSelfPermission(activity, READ_STORAGE) == PackageManager.PERMISSION_DENIED) {
                                ActivityCompat.requestPermissions(activity, STORAGE_PERMISSION, STORAGE_PERMISSION_RESULTCODE);
                            } else {
                                adunit.setVisibility(View.GONE);

                                Date date = new Date();
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append(Environment.getExternalStorageDirectory().toString());
                                stringBuilder.append("/DCIM/"+MainActivity.appName+"/");
                                File file = new File(stringBuilder.toString());
                                if (!file.exists()) {
                                    file.mkdirs();
                                }
                                new Handler().postDelayed(new Runnable(){
                                    @Override
                                    public void run() {

                                        try {
                                            StringBuilder stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(Environment.getExternalStorageDirectory().toString());
                                            stringBuilder2.append("/DCIM/"+MainActivity.appName+"/");
                                            stringBuilder2.append(DateFormat.format("yyyy-MM-dd hh:mm:ss", date));
                                            stringBuilder2.append(".jpg");
                                            String stringBuilder3 = stringBuilder2.toString();
                                            View rootView = getWindow().getDecorView().getRootView();
                                            rootView.setDrawingCacheEnabled(true);
                                            Bitmap createBitmap = Bitmap.createBitmap(rootView.getDrawingCache());
                                            rootView.setDrawingCacheEnabled(false);
                                            OutputStream fileOutputStream = new FileOutputStream(new File(stringBuilder3));
                                            createBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                                            fileOutputStream.flush();
                                            fileOutputStream.close();
                                            MediaScannerConnection.scanFile(MainActivity.this, new String[]{stringBuilder3.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                                final MainActivity a;

                                                {
                                                    this.a = MainActivity.this;
                                                }

                                                public void onScanCompleted(String str, Uri uri) {
                                                }
                                            });
                                            Toast.makeText(MainActivity.this, "Screenshot Taken!", Toast.LENGTH_SHORT).show();
                                            //Snackbar.a(rootView, "Screenshot Taken!", 0).a("Action", null).e();
                                            adunit.setVisibility(View.VISIBLE);
                                            ConfigAds.showInterstitial(activity,true,false);
                                        } catch (Throwable th) {
                                            th.printStackTrace();
                                        }

                                    }
                                }, 1000);
                            }
                        }
                    });

                    reload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            webView.reload();
                            dialog.dismiss();
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });

                    logout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            showSnackbar("logging out...");
                            webView.loadUrl("javascript:localStorage.clear()",null);
                            //mWebView.clearCache(true);
                            WebStorage.getInstance().deleteAllData();
                            //android.webkit.CookieManager.getInstance().removeAllCookie();
                            //clearApplicationData();
                            //mWebView.loadUrl("https://web.whatsapp.com");
                            webView.reload();
                            dialog.dismiss();
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });

                    rate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+getPackageName())));
                            } catch (android.content.ActivityNotFoundException anfe) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
                            }
                            dialog.dismiss();
                        }
                    });

                    share.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                            sharingIntent.setType("text/plain");
                            String shareBody = "Hey my friend(s) check out this amazing application \n https://play.google.com/store/apps/details?id="+ getPackageName() +" \n";
                            sharingIntent.putExtra(Intent.EXTRA_SUBJECT, ""+getResources().getString(R.string.app_name));
                            sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                            startActivity(Intent.createChooser(sharingIntent, "Share via"));
                            dialog.dismiss();
                        }
                    });

                    help.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            startActivity(new Intent(MainActivity.this,GuideActivity.class));
                            dialog.dismiss();
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });

                    screenshots.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            startActivity(new Intent(MainActivity.this,ScreenshotsActivity.class));
                            dialog.dismiss();
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });

                    otherSettings.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            startActivity(new Intent(MainActivity.this,SettingsActivity.class));
                            dialog.dismiss();
                            ConfigAds.showInterstitial(activity,true,false);
                        }
                    });
                }
            });
        }

        private void showError(Context mContext, int errorCode) {
            //Prepare message

            String message = null;
            String title = null;
            if (!isNetworkAvailable()) {
                message = "Failed to access internet. Try again later.";
                title = "No Internet Connection";
            } else if (errorCode == WebViewClient.ERROR_AUTHENTICATION) {
                message = "User authentication failed on server";
                title = "Auth Error";
            } else if (errorCode == WebViewClient.ERROR_TIMEOUT) {
                message = "The server is taking too much time to communicate. Try again later.";
                title = "Connection Timeout";
            } else if (errorCode == WebViewClient.ERROR_TOO_MANY_REQUESTS) {
                message = "Too many requests during this load";
                title = "Too Many Requests";
            } else if (errorCode == WebViewClient.ERROR_UNKNOWN) {
                message = "Generic error";
                title = "Unknown Error";
            } else if (errorCode == WebViewClient.ERROR_BAD_URL) {
                message = "Check entered URL..";
                title = "Malformed URL";
            } else if (errorCode == WebViewClient.ERROR_CONNECT) {
                message = "Failed to connect to the server";
                title = "Connection";
            } else if (errorCode == WebViewClient.ERROR_FAILED_SSL_HANDSHAKE) {
                message = "Failed to perform SSL handshake";
                title = "SSL Handshake Failed";
            } else if (errorCode == WebViewClient.ERROR_HOST_LOOKUP) {
                message = "Server or proxy hostname lookup failed";
                title = "Host Lookup Error";
            } else if (errorCode == WebViewClient.ERROR_PROXY_AUTHENTICATION) {
                message = "User authentication failed on proxy";
                title = "Proxy Auth Error";
            } else if (errorCode == WebViewClient.ERROR_REDIRECT_LOOP) {
                message = "Too many redirects";
                title = "Redirect Loop Error";
            } else if (errorCode == WebViewClient.ERROR_UNSUPPORTED_AUTH_SCHEME) {
                message = "Unsupported authentication scheme (not basic or digest)";
                title = "Auth Scheme Error";
            } else if (errorCode == WebViewClient.ERROR_UNSUPPORTED_SCHEME) {
                message = "Unsupported URI scheme";
                title = "URI Scheme Error";
            } else if (errorCode == WebViewClient.ERROR_FILE) {
                message = "Generic file error";
                title = "File";
            } else if (errorCode == WebViewClient.ERROR_FILE_NOT_FOUND) {
                message = "File not found";
                title = "File";
            } else if (errorCode == WebViewClient.ERROR_IO) {
                message = "The server failed to communicate. Try again later.";
                title = "IO Error";
            }

            if (message != null) {
                new android.support.v7.app.AlertDialog.Builder(mContext)
                        .setMessage(message)
                        .setTitle(title)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setCancelable(false)
                        .setPositiveButton("TRY AGAIN",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        setResult(RESULT_CANCELED);
                                        ConfigAds.initialInterstitial(activity);
                                        ConfigAds.admobBannerCall(activity,adunit);
                                        webView.loadUrl("https://web.whatsapp.com");
                                    }
                                }).show();
            }
        }

        public boolean isNetworkAvailable() {
            // Get Connectivity Manager class object from Systems Service
            ConnectivityManager cm = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);

            // Get Network Info from connectivity Manager
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            // if no network is available networkInfo will be null
            // otherwise check if we are connected
            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
            return false;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (v.getId() == R.id.webview && event.getAction() == MotionEvent.ACTION_DOWN){
                handler.sendEmptyMessageDelayed(CLICK_ON_WEBVIEW, 500);
                ConfigAds.showInterstitial(activity,true,true);
            }
            return false;
        }

        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == CLICK_ON_URL){
                handler.removeMessages(CLICK_ON_WEBVIEW);
                return true;
            }
            if (msg.what == CLICK_ON_WEBVIEW){
                //Toast.makeText(this, "WebView clicked", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        }


    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case VIDEO_PERMISSION_RESULTCODE:
                if (permissions.length == 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    try {
                        currentPermissionRequest.grant(currentPermissionRequest.getResources());
                    } catch (RuntimeException e) {
                        Log.e(DEBUG_TAG, "Granting permissions failed", e);
                    }
                } else {
                    showSnackbar("Permission not granted, can't use video.");
                    currentPermissionRequest.deny();
                }
                break;
            case CAMERA_PERMISSION_RESULTCODE:
            case AUDIO_PERMISSION_RESULTCODE:
                //same same
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    try {
                        currentPermissionRequest.grant(currentPermissionRequest.getResources());
                    } catch (RuntimeException e) {
                        Log.e(DEBUG_TAG, "Granting permissions failed", e);
                    }
                } else {
                    showSnackbar("Permission not granted, can't use " + (requestCode == CAMERA_PERMISSION_RESULTCODE ? "camera" : "microphone"));
                    currentPermissionRequest.deny();
                }
                break;
            case STORAGE_PERMISSION_RESULTCODE:
                if (permissions.length == 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    // TODO: check for current download and enqueue it
                } else {
                    showSnackbar("Permission not granted, can't download to storage");
                }
                break;
            default:
                Log.d(DEBUG_TAG, "Got permission result with unknown request code " + requestCode + " - " + Arrays.asList(permissions).toString());
        }
        currentPermissionRequest = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        webView.restoreState(savedInstanceState);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILECHOOSER_RESULTCODE:
                if (resultCode == RESULT_CANCELED || data.getData() == null) {
                    mUploadMessage.onReceiveValue(null);
                } else {
                    Uri result = data.getData();
                    Uri[] results = new Uri[1];
                    results[0] = result;
                    mUploadMessage.onReceiveValue(results);
                }
                break;
            default:
                Log.d(DEBUG_TAG, "Got activity result with unknown request code " + requestCode + " - " + data.toString());
        }
    }

    private void showSnackbar(String msg) {
        this.runOnUiThread(() -> {
            final Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT);
            snackbar.setAction("dismiss", (View view) -> snackbar.dismiss());
            snackbar.show();
        });
    }

    @Override
    public void onBackPressed() {
        //close drawer if open
        //super.onBackPressed();
        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.dailog_review, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        //alert.setTitle("Delete Contact");
        // this is set the view from XML inside AlertDialog
        alert.setView(alertLayout);
        // disallow cancel of AlertDialog on click of back button and outside touch
        //alert.setCancelable(false);

        alert.setNegativeButton("Improvement", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{SettingsClass.contactMail});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Improvement: "+getPackageName());
                emailIntent.setType("text/plain");
                //emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Messg content");
                final PackageManager pm = getPackageManager();
                final List<ResolveInfo> matches = pm.queryIntentActivities(emailIntent, 0);
                ResolveInfo best = null;
                for(final ResolveInfo info : matches)
                    if (info.activityInfo.packageName.endsWith(".gm") || info.activityInfo.name.toLowerCase().contains("gmail"))
                        best = info;
                if (best != null)
                    emailIntent.setClassName(best.activityInfo.packageName, best.activityInfo.name);
                startActivity(emailIntent);
            }
        });

        alert.setNeutralButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //System.exit(1);
                MainActivity.super.onBackPressed();
            }
        });

        alert.setPositiveButton("Rate", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+getPackageName())));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
                }
            }
        });

        AlertDialog dialog = alert.create();
        if(dialog.isShowing()) dialog.dismiss();
        else dialog.show();
    }

    private void loadWhatsapp(){
        webView.loadUrl(WHATSAPP_WEB_URL);
    }

}
