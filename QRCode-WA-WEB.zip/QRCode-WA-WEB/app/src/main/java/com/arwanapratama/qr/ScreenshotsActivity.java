package com.arwanapratama.qr;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.arwanapratama.qr.func.ConfigAds;
import com.arwanapratama.qr.func.DataUrl;
import com.arwanapratama.qr.adapter.ScreenAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreenshotsActivity extends AppCompatActivity {

    public static List<DataUrl> data = new ArrayList<>();
    public static  File[] listFile;
    public static ArrayList<DataUrl> jData = new ArrayList<>();
    public static File file;
    ActionBar actionBar;
    Toolbar toolbar;
    public static Activity activity;

    public static RecyclerView recyclerView;
    public static ScreenAdapter recyclerAdapter;
    public static LinearLayout adunit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screenshots);
        activity = this;

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar= this.getActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator();
        this.setTitle("Screenshots");

        ConfigAds.initialInterstitial(this);
        adunit = (LinearLayout)findViewById(R.id.unitads);
        ConfigAds.admobBannerCall(this, adunit);

        recyclerView = findViewById(R.id.screenshotsList);
        loadMedia();
    }


    public static void loadMedia(){

        file = new File(Environment.getExternalStorageDirectory()
                    +File.separator+"DCIM"+File.separator+MainActivity.appName+File.separator);

        // use a linear layout manager
        jData.clear();

        if (file.isDirectory()) {

            if(Build.VERSION.SDK_INT >= 23){

                boolean hasPermission = (ContextCompat.checkSelfPermission(activity,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED);

                if (hasPermission) {
                    displayfiles(file, jData, activity);
                }

            }else{
                displayfiles(file, jData, activity);
            }
        }
    }

    public static void displayfiles(File file, ArrayList<DataUrl> jData, Activity a){

        File[] listfilemedia = dirListByAscendingDate(file);


        for (int i = 0; i < listfilemedia.length; i++) {

            if(!listfilemedia[i].isDirectory() && !reg.getBack(listfilemedia[i].getAbsolutePath(), "((\\.jpg|\\.png|\\.jpeg)$)").isEmpty()){
                DataUrl dataUrl = new DataUrl();
                dataUrl.screenName = listfilemedia[i].getName().replace(".jpg","");
                dataUrl.screenURL = listfilemedia[i].getAbsolutePath();
                jData.add(dataUrl);
            }
        }

        if(jData.size() >= 1){
            try{a.findViewById(R.id.no_screenshots).setVisibility(View.GONE);
            }catch(Exception j){}}
        else{
            try{a.findViewById(R.id.no_screenshots).setVisibility(View.VISIBLE);
            }catch(Exception j){}}

//        RecyclerView.Adapter mAdapter = new MyAdapter(getActivity(), jData);
//        mRecyclerView.setAdapter(mAdapter);
//        mAdapter.notifyDataSetChanged();
        recyclerAdapter = new ScreenAdapter(a, jData);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(a,2));

    }


    public static File[] dirListByAscendingDate(File folder) {
        if (!folder.isDirectory()) {
            return null;
        }

        File[] sortedByDate = folder.listFiles();

        if (sortedByDate != null && sortedByDate.length > 1) {
            Arrays.sort(sortedByDate, new Comparator<File>() {
                @Override
                public int compare(File object1, File object2) {
                    return (int) ((object1.lastModified() > object2.lastModified()) ? object1.lastModified(): object2.lastModified());
                }
            });
        }

        return sortedByDate;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        ConfigAds.showInterstitial(activity,true,false);
    }

    public static class reg {

        public static String getBack(String html, String regex){

            Pattern patt = Pattern.compile(regex);
            Matcher match = patt.matcher(html);

            while (match.find()) {

                return match.group(1);

            }
            return "";
        }

        public static ArrayList<String> getBackArray(String html, String regex){

            Pattern patt = Pattern.compile(regex);
            Matcher match = patt.matcher(html);

            ArrayList<String> mylist = new ArrayList<>();

            while (match.find()) {

                mylist.add(match.group(1));

            }
            return mylist;
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return true;
    }

    public static void mShare(String filepath){

        Intent intent = new Intent(Intent.ACTION_SEND, Uri.parse(String.valueOf(filepath)));
        File file = new File(Uri.parse(filepath).getPath());
        Uri MediaURI;

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            MediaURI = FileProvider.getUriForFile(activity, activity.getApplicationContext().getPackageName() + ".provider", file);
        }else{
            MediaURI = Uri.fromFile(file);
        }

        try {
            intent.setDataAndType(MediaURI, "image/*");
            intent.putExtra(Intent.EXTRA_STREAM, MediaURI);
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            activity.startActivity(Intent.createChooser(intent, "Share Image using"));
        }catch (Exception ex){}
    }

}
