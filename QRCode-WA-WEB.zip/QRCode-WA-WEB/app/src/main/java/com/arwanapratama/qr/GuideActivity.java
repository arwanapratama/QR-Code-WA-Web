package com.arwanapratama.qr;


/**
 * Created by asus:KINGDOV on 009/05/2017.
 **/

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.LinearLayout;

import com.google.android.gms.ads.InterstitialAd;
import com.arwanapratama.qr.func.ConfigAds;

public class GuideActivity extends AppCompatActivity {

    ActionBar actionBar;
    Toolbar toolbar;
    InterstitialAd mInterstitialAd;
    public static LinearLayout adunit;
    public static Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar= this.getActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator();
        this.setTitle("Help");

        activity=this;

        ConfigAds.initialInterstitial(this);
        adunit = (LinearLayout)findViewById(R.id.bannerUnitAds);
        ConfigAds.admobBannerCall(this, adunit);


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        ConfigAds.showInterstitial(activity,true,false);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return true;
    }

}