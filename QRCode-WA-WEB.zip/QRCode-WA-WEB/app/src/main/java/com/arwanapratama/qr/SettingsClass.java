package com.arwanapratama.qr;

import android.widget.ImageView;

public class SettingsClass {

    ImageView settings;

    public static String contactMail = "prooo.dev@outlook.com";
    public static String publisherID ="pub-3940256099942544";
    public static String admBanner   = "ca-app-pub-3940256099942544/6300978111";
    public static String Interstitial = "ca-app-pub-3940256099942544/1033173712";
    public static String privacy_policy_url = "https://www.google.com/policies/privacy/";
    public static String more_apps_link = "https://play.google.com/store/apps/dev?id=5700313618786177705";
    public static int nbShowInterstitial = 40, nbShowInterstitial2 = 4;

}
